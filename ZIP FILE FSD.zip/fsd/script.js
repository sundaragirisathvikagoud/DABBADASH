const foods = [
    {id:1, name:"Chicken Biryani", price:220, emoji:"🍛"},
    {id:2, name:"Cheese Burger", price:150, emoji:"🍔"},
    {id:3, name:"Veg Pizza", price:199, emoji:"🍕"},
    {id:4, name:"Veg Noodles", price:120, emoji:"🍜"},
    {id:5, name:"Sandwich", price:100, emoji:"🥪"},
    {id:6, name:"Cold Drink", price:50, emoji:"🥤"}
];

const stages = [
    "Order Placed",
    "Preparing Food",
    "Food Packed",
    "Out for Delivery",
    "Delivered"
];

const DELIVERY_FEE = 30;

function getData(key, fallback) {
    try {
        return JSON.parse(localStorage.getItem(key)) ?? fallback;
    } catch {
        return fallback;
    }
}

function saveData(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

let cart = getData("dabbaCart", []);

// CART COUNT

function updateCartCount() {
    const count = document.getElementById("cartCount");

    if (count) {
        count.textContent = cart.reduce(
            (sum, item) => sum + item.quantity, 0
        );
    }
}

// ADD TO CART

function addToCart(id) {
    const food = foods.find(item => item.id === id);

    if (!food) return;

    const existing = cart.find(item => item.id === id);

    if (existing) {
        existing.quantity++;
    } else {
        cart.push({...food, quantity:1});
    }

    saveData("dabbaCart", cart);
    updateCartCount();

    alert(food.name + " added to cart!");
}

// DISPLAY CART

function displayCart() {
    const cartItems = document.getElementById("cartItems");

    if (!cartItems) return;

    if (cart.length === 0) {
        cartItems.innerHTML =
            '<p>Your cart is empty. <a href="menu.html">Browse food</a></p>';

        document.getElementById("cartSubtotal").textContent = "0";
        document.getElementById("deliveryFee").textContent = "0";
        document.getElementById("cartTotal").textContent = "0";
        return;
    }

    cartItems.innerHTML = cart.map(item => `
        <div class="cart-row">
            <div>
                <h3>${item.emoji} ${item.name}</h3>
                <p>₹${item.price} each</p>
            </div>

            <div class="qty-controls">
                <button onclick="changeQuantity(${item.id}, -1)">−</button>
                <b>${item.quantity}</b>
                <button onclick="changeQuantity(${item.id}, 1)">+</button>
            </div>

            <button onclick="removeItem(${item.id})">
                Remove
            </button>
        </div>
    `).join("");

    calculateTotal();
}

// CHANGE QUANTITY

function changeQuantity(id, amount) {
    const item = cart.find(x => x.id === id);

    if (!item) return;

    item.quantity += amount;

    if (item.quantity <= 0) {
        cart = cart.filter(x => x.id !== id);
    }

    saveData("dabbaCart", cart);
    updateCartCount();
    displayCart();
}

// REMOVE FOOD

function removeItem(id) {
    cart = cart.filter(item => item.id !== id);

    saveData("dabbaCart", cart);
    updateCartCount();
    displayCart();
}

// CALCULATE TOTAL

function calculateTotal() {
    const subtotal = cart.reduce(
        (sum, item) => sum + item.price * item.quantity, 0
    );

    const fee = subtotal > 0 ? DELIVERY_FEE : 0;

    document.getElementById("cartSubtotal").textContent = subtotal;
    document.getElementById("deliveryFee").textContent = fee;
    document.getElementById("cartTotal").textContent = subtotal + fee;
}

// LOGIN

const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const name = document.getElementById("customerName").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;

        if (!name || !email || password.length < 4) {
            return;
        }

        saveData("dabbaUser", {
            name: name,
            email: email
        });

        document.getElementById("loginMessage").textContent =
            "Login Successful! Welcome " + name;

        setTimeout(() => {
            window.location.href = "menu.html";
        }, 800);
    });
}

// PLACE ORDER

function placeOrder() {
    const message = document.getElementById("cartMessage");

    if (cart.length === 0) {
        message.textContent = "Your cart is empty!";
        return;
    }

    const user = getData("dabbaUser", null);

    if (!user) {
        alert("Please login before placing your order.");
        window.location.href = "login.html";
        return;
    }

    const subtotal = cart.reduce(
        (sum, item) => sum + item.price * item.quantity, 0
    );

    const order = {
        id: "DD" + Date.now().toString().slice(-7),
        customer: user.name,
        items: cart,
        amount: subtotal + DELIVERY_FEE,
        statusIndex: 0
    };

    saveData("dabbaOrder", order);

    cart = [];
    saveData("dabbaCart", cart);

    alert("Order placed successfully!");

    window.location.href = "tracking.html";
}

// DISPLAY TRACKING

function displayTracking() {
    const orderId = document.getElementById("orderId");

    if (!orderId) return;

    const order = getData("dabbaOrder", null);

    if (!order) {
        orderId.textContent = "No Order Found";

        document.getElementById("currentStatus").textContent =
            "Please place an order first.";

        document.getElementById("advanceButton").disabled = true;
        return;
    }

    orderId.textContent = order.id;

    document.getElementById("trackCustomer").textContent =
        order.customer;

    document.getElementById("trackAmount").textContent =
        "₹" + order.amount;

    stages.forEach((stage, index) => {
        document.getElementById("step" + index)
            .classList.toggle("active", index <= order.statusIndex);
    });

    document.getElementById("currentStatus").textContent =
        "Current Status: " + stages[order.statusIndex];

    const button = document.getElementById("advanceButton");

    button.disabled = order.statusIndex === 4;

    button.textContent = order.statusIndex === 4
        ? "Order Delivered ✓"
        : "Update Demo Status";
}

// UPDATE ORDER STATUS

function advanceTracking() {
    const order = getData("dabbaOrder", null);

    if (!order) return;

    if (order.statusIndex < stages.length - 1) {
        order.statusIndex++;

        saveData("dabbaOrder", order);

        displayTracking();
    }
}

// INITIALIZE

updateCartCount();
displayCart();
displayTracking();